package com.magical_dimas.okbudget;

import android.app.Activity;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.icu.number.NumberFormatter;
import android.os.Bundle;
import android.text.format.DateUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.NonNull;

import java.util.ArrayList;
import java.util.Calendar;

import static com.magical_dimas.okbudget.MainActivity.date1;
import static com.magical_dimas.okbudget.MainActivity.date2;
import static com.magical_dimas.okbudget.MainActivity.dbhelper;

public class Days extends Activity {
    ListView dayslv;
    public static DayAdapter dayAdapter;
    ArrayList<Day> days = new ArrayList<Day>();
    boolean changed = false;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.days);
        dayslv = findViewById(R.id.dayslv);
        dayAdapter = new DayAdapter(this, days);
        dayAdapter.init();
        dayslv.setAdapter(dayAdapter);
    }
    SQLiteDatabase db = dbhelper.getWritableDatabase();
    public class DayAdapter extends BaseAdapter {
        private Context context;
        private ArrayList <Day> gg = null;

        public DayAdapter(Context context, ArrayList <Day> gg) {
            this.context = context;
            this.gg = gg;
        }

        @Override
        public int getCount() {
            if (gg == null) return 0;
            else return gg.size();
        }

        @Override
        public Object getItem(int i) {
            return gg.get(i);
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        public void init (){
                days.clear();
                for (int i = 0; i < 1+date2-date1; i++) {
                    Cursor cursed = db.query("money", new String[] {"amount", "comment", "date", "categoryid"},
                            "date = ?", new String [] {Integer.toString(i+date1)},
                            null, null, "id ASC");
                    if (cursed.getCount() > 0) {
                        Day day = new Day();
                        day.Amount = 0;
                        int dateint = 0;
                        while (cursed.moveToNext()) {
                            dateint = cursed.getInt(cursed.getColumnIndex("date"));
                            Cursor cursor = db.query("categories", new String [] {"posneg"},
                                    "id = ?",
                                    new String [] {Integer.toString(cursed.getInt(cursed.getColumnIndex("categoryid")))},
                                    null, null, null);
                            cursor.moveToFirst();
                            int a = (int)Math.pow(-1 ,cursor.getInt(cursor.getColumnIndex("posneg")));
                            cursor.close();
                            DayContents daycontent = new DayContents();
                            daycontent.amount = a*cursed.getDouble(cursed.getColumnIndex("amount"));
                            day.Amount+=daycontent.amount;
                            daycontent.comment = cursed.getString(cursed.getColumnIndex("comment"));
                            day.dc.add(daycontent);
                        }
                        Calendar c = Calendar.getInstance();
                        c.set(Math.round(dateint / 10000),
                                Math.round((dateint % 10000) / 100 - 1),
                                dateint % 100);
                        day.Date = (DateUtils.formatDateTime(context,
                                c.getTimeInMillis(),
                                DateUtils.FORMAT_SHOW_YEAR));
                        day.Weeksday = (DateUtils.formatDateTime(context,
                                c.getTimeInMillis(),
                                DateUtils.FORMAT_SHOW_WEEKDAY));
                        days.add(day);
                    }
                    cursed.close();

                }
                dayAdapter.notifyDataSetChanged();
            }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            View v = convertView;

            if (v == null) {
                LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                v = inflater.inflate(R.layout.day, null);
            }
            TextView date = v.findViewById(R.id.dateday);
            TextView weeksday = v.findViewById(R.id.weeksday);
            TextView amount = v.findViewById(R.id.weeksdayamount);
            ListView lv = v.findViewById(R.id.daylv);
            date.setText(gg.get(position).Date);
            weeksday.setText(gg.get(position).Weeksday);
            if (gg.get(position).Amount % 1 == 0) amount.setText(Integer.toString((int)(gg.get(position).Amount)));
            else amount.setText(Double.toString(gg.get(position).Amount));
            if (gg.get(position).Amount > 0) amount.setTextColor(Color.GREEN);
            if (gg.get(position).Amount < 0) amount.setTextColor(Color.RED);
            InnerAdapter innerAdapter = new InnerAdapter(context, gg.get(position).dc);
            lv.setAdapter(innerAdapter);
            setListViewHeightBasedOnChildren(lv);
            return v;
        }
    }
    public static void setListViewHeightBasedOnChildren(ListView listView) {
        InnerAdapter adapter = (InnerAdapter) listView.getAdapter();
        if (adapter == null) {
            return;
        }

        int totalHeight = 0;
        for (int i = 0; i < adapter.getCount(); i++) {
            View listItem = adapter.getView(i, null, listView);
            listItem.measure(0, 0);
            totalHeight += listItem.getMeasuredHeight();
        }

        ViewGroup.LayoutParams params = listView.getLayoutParams();
        params.height = totalHeight + (listView.getDividerHeight() * (adapter.getCount() - 1));
        listView.setLayoutParams(params);
    }
    public class InnerAdapter extends BaseAdapter {
        private Context innerContext;
        private ArrayList<DayContents> dayContents = null;
        public InnerAdapter (Context context, ArrayList <DayContents> dc){
            dayContents = dc;
            innerContext = context;
        }
        @Override
        public int getCount() {
            if (dayContents == null) return 0;
            else return dayContents.size();
        }

        @Override
        public Object getItem(int i) {
            return dayContents.get(i);
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            View v = convertView;

            if (v == null) {
                LayoutInflater inflater = (LayoutInflater) innerContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                v = inflater.inflate(R.layout.day_content, null);
            }
            TextView com = v.findViewById(R.id.daycom);
            TextView am = v.findViewById(R.id.dayamount);
            com.setText(dayContents.get(position).comment);
            if (dayContents.get(position).amount % 1 == 0) am.setText(Integer.toString((int)(dayContents.get(position).amount)));
            else am.setText(Double.toString(dayContents.get(position).amount));
            return v;
        }
    }
    public class Day {
        String Date;
        String Weeksday;
        double Amount;
        ArrayList <DayContents> dc = new ArrayList<DayContents>();
    }
    public class  DayContents{
        String comment;
        double amount;
    }
}