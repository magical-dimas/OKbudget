package com.magical_dimas.okbudget;

import android.app.DatePickerDialog;
import android.app.TabActivity;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Paint;
import android.os.Bundle;
import android.text.format.DateUtils;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Display;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TabHost;
import android.widget.TextView;
import android.widget.ViewFlipper;

import androidx.appcompat.app.ActionBar;
import androidx.constraintlayout.utils.widget.ImageFilterButton;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;

import static com.magical_dimas.okbudget.Categories.groupAdapter;
import static com.magical_dimas.okbudget.Days.dayAdapter;
import static com.magical_dimas.okbudget.Editing.arrayAdaptercateg;
import static com.magical_dimas.okbudget.Editing.arrayAdapterposneg;
import static com.magical_dimas.okbudget.Editing.categ;
import static com.magical_dimas.okbudget.Editing.customAdapter;
import static com.magical_dimas.okbudget.Statistics.adapter;

public class MainActivity extends TabActivity {
    Button chosendate1, chosendate2;
    ImageButton help, settings;
    public static String LOG_TAG = "MD";
    Calendar datecal2 = Calendar.getInstance();
    Calendar datecal1 = Calendar.getInstance();
    public static DBhelper dbhelper;
    public static int date1, date2;
    static boolean flag = false;
    static ViewFlipper viewFlipper;
    static String [] resourcestrings;
    Spinner languagespin;
    String [] languages = {"English", "Russian"};
    String [] themes = {"Light", "Dark"};
    ArrayAdapter languageadapter;
    TabHost tabHost;
    static SQLiteDatabase db;
    public static boolean ischanged = false;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_MASK_ADJUST);
        if (dbhelper == null) {
            dbhelper = new DBhelper(this);
        }
        db = dbhelper.getWritableDatabase();
        Cursor cursed = db.query("settings", new String[] {"language"},
                null, null, null, null, null);
        cursed.moveToFirst();
        int langsetpos = cursed.getInt(cursed.getColumnIndex("language"));
        cursed.close();
        changelanguagesettings(langsetpos);
        setContentView(R.layout.activity_main);
        tabHost = getTabHost();
        TabHost.TabSpec tabSpec;

        tabSpec = tabHost.newTabSpec("tag1");
        tabSpec.setIndicator(resourcestrings[5]);
        tabSpec.setContent(new Intent(this, Statistics.class));
        tabHost.addTab(tabSpec);

        tabSpec = tabHost.newTabSpec("tag2");
        tabSpec.setIndicator(resourcestrings[6]);
        tabSpec.setContent(new Intent(this, Categories.class));
        tabHost.addTab(tabSpec);

        tabSpec = tabHost.newTabSpec("tag3");
        tabSpec.setIndicator(resourcestrings[7]);
        tabSpec.setContent(new Intent(this, Days.class));
        tabHost.addTab(tabSpec);

        tabSpec = tabHost.newTabSpec("tag4");
        tabSpec.setIndicator(resourcestrings[8]);
        tabSpec.setContent(new Intent(this, Editing.class));
        tabHost.addTab(tabSpec);
        Float dens = getResources().getDisplayMetrics().density;
        TextView x = (TextView) tabHost.getTabWidget().getChildAt(0).findViewById(android.R.id.title); x.setTextSize(((x.length()*x.getTextSize()*3/5)/(x.length())/dens));
        x = (TextView) tabHost.getTabWidget().getChildAt(1).findViewById(android.R.id.title); x.setTextSize(((x.length()*x.getTextSize()*3/5)/(x.length())/dens));
        x = (TextView) tabHost.getTabWidget().getChildAt(2).findViewById(android.R.id.title); x.setTextSize(((x.length()*x.getTextSize()*3/5)*3/2/(x.length())/dens));
        x = (TextView) tabHost.getTabWidget().getChildAt(3).findViewById(android.R.id.title); x.setTextSize(((x.length()*x.getTextSize()*3/5)*3/2/(x.length())/dens));
        if (flag){
            datecal1.set(Math.round(date1 / 10000),
                    Math.round((date1 % 10000) / 100 - 1),
                    date1 % 100);
            datecal2.set(Math.round(date2 / 10000),
                    Math.round((date2 % 10000) / 100 - 1),
                    date2 % 100);
        }
        else {
            int day1 =  1 - (datecal1.get(Calendar.DAY_OF_WEEK)+6)%7;
            int day2 = 7 - (datecal2.get(Calendar.DAY_OF_WEEK)+6)%7;
            if (day1==1){
                day1 = -6;
                day2 = 0;
            }
            datecal1.set(datecal1.get(Calendar.YEAR), datecal1.get(Calendar.MONTH), datecal1.get(Calendar.DAY_OF_MONTH) + day1);
            datecal2.set(datecal2.get(Calendar.YEAR), datecal2.get(Calendar.MONTH), datecal2.get(Calendar.DAY_OF_MONTH) + day2);
            flag = true;
        }
        chosendate1 = (Button) findViewById(R.id.date1);
        chosendate2 = (Button) findViewById(R.id.date2);
        help = (ImageButton) findViewById(R.id.helpbt);
        settings = (ImageButton) findViewById(R.id.settingsbt);
        setInitialDateTime();
        viewFlipper = (ViewFlipper) findViewById(R.id.viewflipper);
        TextView ttvv = (TextView) findViewById(R.id.helphead);
        TextView ttv = (TextView) findViewById(R.id.sethead);
        DisplayMetrics metrics;
        metrics = getApplicationContext().getResources().getDisplayMetrics();
        float Textsize =ttvv.getTextSize()/metrics.density;
        ttvv.setTextSize(Textsize*2);
        ttv.setTextSize(Textsize*2);
        languagespin = (Spinner) findViewById(R.id.langspinner);
        languageadapter = new ArrayAdapter(this, R.layout.support_simple_spinner_dropdown_item, languages);
        languagespin.setAdapter(languageadapter);
        languagespin.setSelection(langsetpos);
        updatetexts();
        languagespin.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                ContentValues cv = new ContentValues();
                cv.put("language", i);
                db.update("settings", cv, null, null);
                changelanguagesettings(i);
                updatetexts();
                adapter.initstats();
                if (dayAdapter != null) {
                    dayAdapter.init();
                }
                if (customAdapter != null) {
                    customAdapter.notifyDataSetChanged();
                }
                if (arrayAdapterposneg!=null) {
                    arrayAdapterposneg.notifyDataSetChanged();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
    }
    public void updatetexts (){
        chosendate1.setText((DateUtils.formatDateTime(this,
                datecal1.getTimeInMillis(),
                DateUtils.FORMAT_SHOW_DATE | DateUtils.FORMAT_SHOW_YEAR
        )));
        chosendate2.setText(DateUtils.formatDateTime(this,
                datecal2.getTimeInMillis(),
                DateUtils.FORMAT_SHOW_DATE | DateUtils.FORMAT_SHOW_YEAR
        ));
        TextView sethead = (TextView)findViewById(R.id.sethead);
        TextView setlang = (TextView)findViewById(R.id.setlang);
        TextView helphead = (TextView)findViewById(R.id.helphead);

        TextView help1 = findViewById(R.id.help1);
        TextView help2 = findViewById(R.id.help2);
        TextView help3 = findViewById(R.id.help3);
        TextView help4 = findViewById(R.id.help4);
        TextView help5 = findViewById(R.id.help5);
        TextView help6 = findViewById(R.id.help6);
        TextView help7 = findViewById(R.id.help7);
        TextView help8 = findViewById(R.id.help8);
        TextView help9 = findViewById(R.id.help9);
        TextView help10 = findViewById(R.id.help10);
        TextView help11 = findViewById(R.id.help11);
        TextView help12 = findViewById(R.id.help12);
        TextView help13 = findViewById(R.id.help13);
        TextView help14 = findViewById(R.id.help14);
        TextView help15 = findViewById(R.id.help15);
        TextView help16 = findViewById(R.id.help16);
        TextView help17 = findViewById(R.id.help17);
        TextView help18 = findViewById(R.id.help18);

        sethead.setText(resourcestrings[3]);
        setlang.setText(resourcestrings[16]);
        helphead.setText(resourcestrings[4]);
        languages[0] = resourcestrings[19];
        languages[1] = resourcestrings[18];
        themes [0] = resourcestrings [21];
        themes [1] = resourcestrings [20];
        help1.setText(resourcestrings[31]);
        help2.setText(resourcestrings[32]);
        help3.setText(resourcestrings[33]);
        help4.setText(resourcestrings[34]);
        help5.setText(resourcestrings[35]);
        help6.setText(resourcestrings[36]);
        help7.setText(resourcestrings[37]);
        help8.setText(resourcestrings[38]);
        help9.setText(resourcestrings[39]);
        help10.setText(resourcestrings[40]);
        help11.setText(resourcestrings[41]);
        help12.setText(resourcestrings[42]);
        help13.setText(resourcestrings[43]);
        help14.setText(resourcestrings[44]);
        help15.setText(resourcestrings[45]);
        help16.setText(resourcestrings[46]);
        help17.setText(resourcestrings[47]);
        help18.setText(resourcestrings[48]);

        languageadapter.notifyDataSetChanged();
        TextView x = (TextView) tabHost.getTabWidget().getChildAt(0).findViewById(android.R.id.title); x.setText(resourcestrings[5]);
        x = (TextView) tabHost.getTabWidget().getChildAt(1).findViewById(android.R.id.title); x.setText(resourcestrings[6]);
        x = (TextView) tabHost.getTabWidget().getChildAt(2).findViewById(android.R.id.title); x.setText(resourcestrings[7]);
        x = (TextView) tabHost.getTabWidget().getChildAt(3).findViewById(android.R.id.title); x.setText(resourcestrings[8]);
    }
    private void setInitialDateTime() {

        chosendate1.setText(DateUtils.formatDateTime(this,
                datecal1.getTimeInMillis(),
                DateUtils.FORMAT_SHOW_DATE | DateUtils.FORMAT_SHOW_YEAR
                        ));
        date1 = datecal1.get(Calendar.DAY_OF_MONTH)+(datecal1.get(Calendar.MONTH)+1)*100+datecal1.get(Calendar.YEAR)*10000;
        chosendate2.setText(DateUtils.formatDateTime(this,
                datecal2.getTimeInMillis(),
                DateUtils.FORMAT_SHOW_DATE | DateUtils.FORMAT_SHOW_YEAR
                        ));
        date2 = datecal2.get(Calendar.DAY_OF_MONTH)+(datecal2.get(Calendar.MONTH)+1)*100+datecal2.get(Calendar.YEAR)*10000;

        if (date1>date2) {

            Calendar temp = datecal1;
            datecal1 = datecal2;
            datecal2 = temp;
            setInitialDateTime();

        }

    }
    public void setDate1 (View v) {
        new DatePickerDialog(MainActivity.this, d1,
                datecal1.get(Calendar.YEAR),
                datecal1.get(Calendar.MONTH),
                datecal1.get(Calendar.DAY_OF_MONTH))
                .show();
    }
    public void setDate2 (View v) {
        new DatePickerDialog(MainActivity.this, d2,
                datecal2.get(Calendar.YEAR),
                datecal2.get(Calendar.MONTH),
                datecal2.get(Calendar.DAY_OF_MONTH))
                .show();
    }
    DatePickerDialog.OnDateSetListener d1=new DatePickerDialog.OnDateSetListener() {
        public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
            datecal1.set(Calendar.YEAR, year);
            datecal1.set(Calendar.MONTH, monthOfYear);
            datecal1.set(Calendar.DAY_OF_MONTH, dayOfMonth);
            setInitialDateTime();
            if (adapter!=null)
            adapter.initstats();
            if (groupAdapter!=null)
                groupAdapter.initthis();
            if (dayAdapter!=null)
                dayAdapter.init();
        }
    };
    DatePickerDialog.OnDateSetListener d2=new DatePickerDialog.OnDateSetListener() {
        public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
            datecal2.set(Calendar.YEAR, year);
            datecal2.set(Calendar.MONTH, monthOfYear);
            datecal2.set(Calendar.DAY_OF_MONTH, dayOfMonth);
            setInitialDateTime();
            if (adapter!=null)
            adapter.initstats();
            if (groupAdapter!=null)
            groupAdapter.initthis();
            if (dayAdapter!=null)
                dayAdapter.init();
        }
    };
    public void helpme (View v) {
        viewFlipper.showNext();
        viewFlipper.showNext();
    }
    public void setthisman (View v) {
        viewFlipper.showNext();
    }
    public void back (View v) {
        switch (v.getId()){
            case R.id.backhelp:
                viewFlipper.showPrevious();
                viewFlipper.showPrevious();
                break;
            case R.id.backset:
                viewFlipper.showPrevious();
                break;
        }
    }
    public void changelanguagesettings(int pos) {
        String b;
        if (pos == 0) {
            resourcestrings = getResources().getStringArray(R.array.EnglishStrings);
            for (int i = 0; i < 6; i++) {
                ContentValues cv = new ContentValues();
                cv.put("name", resourcestrings[25+i]);
                if (i!=2) {
                    cv.put("posneg", 1);
                } else {
                    cv.put("posneg", 0);
                }
                db.update("categories", cv, "id = ?", new String[]{Integer.toString(i+1)});
            }
            b = "en_US";
        } else {
            resourcestrings = getResources().getStringArray(R.array.RussianStrings);
            for (int i = 0; i < 6; i++) {
                ContentValues cv = new ContentValues();
                cv.put("name", resourcestrings[25+i]);
                if (i!=2) {
                    cv.put("posneg", 1);
                } else {
                    cv.put("posneg", 0);
                }
                db.update("categories", cv, "id = ?", new String[]{Integer.toString(i+1)});
            }
            b = "ru";
        }
        if (arrayAdaptercateg!=null) {
            categ.clear();
            Cursor cursor = db.query("categories",
                    new String[]{"name"},
                    null,
                    null,
                    null,
                    null,
                    "id ASC"
            );
            if (cursor != null) {
                while (cursor.moveToNext()) {
                    String str = cursor.getString(cursor.getColumnIndex("name"));
                    categ.add(str);
                }
            }
            cursor.close();
            ischanged = true;
            arrayAdaptercateg.notifyDataSetChanged();
        }
        if (groupAdapter!=null)
        groupAdapter.initthis();
        Locale locale = new Locale(b);
        Locale.setDefault(locale);
        Configuration config = new Configuration();
        config.locale = locale;
        this.getApplicationContext().getResources().updateConfiguration(config, null);
    }
}