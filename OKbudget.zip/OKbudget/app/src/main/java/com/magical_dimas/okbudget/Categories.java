package com.magical_dimas.okbudget;

import android.app.Activity;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.TextView;

import java.util.ArrayList;


import static com.magical_dimas.okbudget.MainActivity.date1;
import static com.magical_dimas.okbudget.MainActivity.date2;
import static com.magical_dimas.okbudget.MainActivity.dbhelper;

public class Categories extends Activity {
    ExpandableListView lv;
    public ArrayList <GroupItem> groups = new ArrayList<GroupItem>();
    public static GroupAdapter groupAdapter;


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.categories);
        lv = findViewById(R.id.catlv);
        if (groupAdapter == null){
            groupAdapter = new GroupAdapter(this, groups);
        }
        groupAdapter.initthis();
        lv.setAdapter(groupAdapter);
    }
    SQLiteDatabase db = dbhelper.getWritableDatabase();

    public class GroupAdapter extends BaseExpandableListAdapter{

        private Context mcontext;
        private ArrayList <GroupItem> mgroups = new ArrayList<GroupItem>();

        public GroupAdapter (Context context, ArrayList<GroupItem> groups) {
            mcontext = context;
            mgroups = groups;
        }

        @Override
        public int getGroupCount() {
            return mgroups.size();
        }

        @Override
        public int getChildrenCount(int groupPosition) {
            return mgroups.get(groupPosition).size();
        }

        @Override
        public Object getGroup(int groupPosition) {
            return mgroups.get(groupPosition);
        }

        @Override
        public Object getChild(int groupPosition, int childPosition) {
            return mgroups.get(groupPosition).get(childPosition);
        }

        @Override
        public long getGroupId(int groupPosition) {
            return groupPosition;
        }

        @Override
        public long getChildId(int groupPosition, int childPosition) {
            return childPosition;
        }

        @Override
        public boolean hasStableIds() {
            return true;
        }

        @Override
        public View getGroupView(int groupPosition, boolean isExpanded, View convertView,
                                 ViewGroup parent) {

            if (convertView == null) {
                LayoutInflater inflater = (LayoutInflater) mcontext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                convertView = inflater.inflate(R.layout.catgroup, null);
            }
            TextView name = (TextView) convertView.findViewById(R.id.textcatgroup);
            TextView amount = (TextView) convertView.findViewById(R.id.catgroupamount);
            name.setText(groups.get(groupPosition).name);
            double g = groups.get(groupPosition).amount;
            if (g % 1 == 0) {
                amount.setText(Integer.toString((int)g));
            } else {
                amount.setText(Double.toString(g));
            }
            if (groups.get(groupPosition).negative == 0){
               amount.setTextColor(Color.GREEN);
            } else {
                amount.setTextColor(Color.RED);
            }
            return convertView;

        }

        @Override
        public View getChildView(int groupPosition, int childPosition, boolean isLastChild,
                                 View convertView, ViewGroup parent) {
            if (convertView == null) {
                LayoutInflater inflater = (LayoutInflater) mcontext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                convertView = inflater.inflate(R.layout.catchild, null);
            }
            TextView name = (TextView) convertView.findViewById(R.id.catchildname);
            TextView amount = (TextView) convertView.findViewById(R.id.catchildamount);
            name.setText(groups.get(groupPosition).get(childPosition).name);
            double g = groups.get(groupPosition).get(childPosition).amount;
            if (g % 1 == 0) {
                amount.setText(Integer.toString((int)g));
            } else {
                amount.setText(Double.toString(g));
            }
            return convertView;
        }

        @Override
        public boolean isChildSelectable(int groupPosition, int childPosition) {
            return true;
        }
        public void initthis (){
            groups.clear();
            Cursor cursor = db.query("categories", new String[] {"id", "name", "posneg"},
                    null, null,
                    null, null, "id ASC");
            if (cursor!=null) {
                while (cursor.moveToNext()){
                    GroupItem gr = new GroupItem();
                    gr.id = cursor.getInt(cursor.getColumnIndex("id"));
                    gr.name = cursor.getString(cursor.getColumnIndex("name"));
                    gr.negative = cursor.getInt(cursor.getColumnIndex("posneg"));
                    gr.amount = 0.0;
                    Cursor cursed = db.query("money", new String[] {"amount", "comment"},
                            "date >= ? and date <= ? and categoryid = ?",
                            new String[]{Integer.toString(date1), Integer.toString(date2),
                                    Integer.toString(gr.id)},
                            null, null, "id ASC");
                    if (cursed!=null){
                        while (cursed.moveToNext()){
                            ChildItem ci = new ChildItem();
                            ci.name = cursed.getString(cursed.getColumnIndex("comment"));
                            ci.amount = cursed.getInt(cursed.getColumnIndex("amount"));
                            gr.childItems.add(ci);
                            gr.amount+=ci.amount;
                        }
                        cursed.close();
                    }
                    if (gr.childItems.size()!=0) {groups.add(gr);}
                }
                cursor.close();
            }
            groupAdapter.notifyDataSetChanged();
        }
    }
    public class GroupItem {
        String name;
        Double amount;
        int id;
        int negative; // boolean alternative
        ArrayList <ChildItem> childItems = new ArrayList<ChildItem>();

        public ChildItem get (int position){
            return childItems.get(position);
        }
        public int size (){
            return childItems.size();
        }
        public void add (ChildItem item){
            childItems.add(item);
        }
    }
    public class ChildItem {
        String name;
        double amount;
    }
}