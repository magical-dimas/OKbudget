package com.magical_dimas.okbudget;

import android.widget.EditText;
import android.widget.Spinner;

public class Item {

    String edit1;
    String edit2;
    int id;
    int chosencategory;

}
