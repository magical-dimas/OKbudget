package com.magical_dimas.okbudget;

import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.Button;
import android.widget.ExpandableListView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

import javax.crypto.Cipher;

import static com.magical_dimas.okbudget.MainActivity.LOG_TAG;
import static com.magical_dimas.okbudget.MainActivity.date1;
import static com.magical_dimas.okbudget.MainActivity.date2;
import static com.magical_dimas.okbudget.MainActivity.dbhelper;
import static com.magical_dimas.okbudget.MainActivity.resourcestrings;

public class Statistics extends Activity {
    ImageView ivmain;
    ExpandableListView lv;
    public static explistadapter adapter;
    static ArrayList <Integer> colors = new ArrayList<Integer>();
    ArrayList <Rec> concat = new ArrayList<Rec>();
    ArrayList <Rec> reclistpos = new ArrayList<Rec>();
    ArrayList <Rec> reclistneg = new ArrayList<Rec>();
    ArrayList <ArrayList<Rec>> groups = new ArrayList<ArrayList<Rec>>();
    double [] amountgroup = new double[] {0, 0};

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.statistics);
        adapter = new explistadapter(this, groups);
        adapter.initstats();
        lv = (ExpandableListView) findViewById(R.id.statisticslv);
        lv.setAdapter(adapter);
    }

    SQLiteDatabase db = dbhelper.getWritableDatabase();
    public static void drawPieChart(Bitmap bmp, ArrayList <Integer> colors, ArrayList <Rec> slices){
        Canvas canvas = new Canvas(bmp);
        RectF box = new RectF(2, 2,bmp.getWidth() , bmp.getHeight());
        int sum = 0;
        for (Rec slice : slices) {
            sum += slice.amount;
        }
        Paint paint = new Paint();
        paint.setAntiAlias(true);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(1f);
        paint.setStyle(Paint.Style.FILL_AND_STROKE);
        float start = 0;
        for(int i =0; i < slices.size(); i++){
            paint.setColor(colors.get((slices.get(i).id) -1));
            double angle;
            angle = ((360.0f / sum) * slices.get(i).amount);
            canvas.drawArc(box, start, (float) angle, true, paint);
            start += angle;
        }
    }
    public class explistadapter extends BaseExpandableListAdapter {
        private ArrayList<ArrayList<Rec>> mGroups;
        private Context mContext;

        public explistadapter (Context context, ArrayList<ArrayList<Rec>> groups){
            mContext = context;
            mGroups = groups;
        }
        @Override
        public int getGroupCount() {
            return mGroups.size();
        }

        @Override
        public int getChildrenCount(int groupPosition) {
            return mGroups.get(groupPosition).size();
        }

        @Override
        public Object getGroup(int groupPosition) {
            return mGroups.get(groupPosition);
        }

        @Override
        public Object getChild(int groupPosition, int childPosition) {
            return mGroups.get(groupPosition).get(childPosition);
        }

        @Override
        public long getGroupId(int groupPosition) {
            return groupPosition;
        }

        @Override
        public long getChildId(int groupPosition, int childPosition) {
            return childPosition;
        }

        @Override
        public boolean hasStableIds() {
            return true;
        }

        @Override
        public View getGroupView(int groupPosition, boolean isExpanded, View convertView,
                                 ViewGroup parent) {

            if (convertView == null) {
                LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                convertView = inflater.inflate(R.layout.statsgroup, null);
            }

            TextView textGroup = (TextView) convertView.findViewById(R.id.textGroup);
            TextView groupamount = (TextView) convertView.findViewById(R.id.groupamount);
            if (groupPosition == 0) {groupamount.setTextColor(Color.GREEN);
            textGroup.setText(resourcestrings[1]);
            if (amountgroup[0]%1 == 0) {
                int b = (int) amountgroup[0];
                groupamount.setText(Integer.toString(b));
            }
            else {
                double b =  amountgroup[0];
                groupamount.setText(Double.toString(b));
            }
            }
            else {groupamount.setTextColor(Color.RED);
            textGroup.setText(resourcestrings[2]);
                if (amountgroup[1]%1 == 0) {
                    int b = (int) amountgroup[1];
                    groupamount.setText(Integer.toString(b));
                }
                else {
                    double b =  amountgroup[1];
                    groupamount.setText(Double.toString(b));
                }
            }

            return convertView;

        }

        @Override
        public View getChildView(int groupPosition, int childPosition, boolean isLastChild,
                                 View convertView, ViewGroup parent) {
            if (convertView == null) {
                LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                convertView = inflater.inflate(R.layout.statschild, null);
            }

            TextView childname = (TextView) convertView.findViewById(R.id.childname);
            TextView childamount = (TextView) convertView.findViewById(R.id.childamount);
            childname.setText(groups.get(groupPosition).get(childPosition).name);
            if (groups.get(groupPosition).get(childPosition).amount % 1 != 0) {
                childamount.setText(Double.toString(groups.get(groupPosition).get(childPosition).amount));
            }
            else {
                childamount.setText(Integer.toString((int)groups.get(groupPosition).get(childPosition).amount));
            }
            Bitmap bitmap = Bitmap.createBitmap((int)(childname.getTextSize()*1.4), (int)(childname.getTextSize()*1.4),
                    Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(bitmap);
            RectF box = new RectF(0, 0,bitmap.getWidth(), bitmap.getHeight());
            Paint paint = new Paint();
            paint.setAntiAlias(true);
            paint.setStyle(Paint.Style.FILL_AND_STROKE);
            paint.setStrokeWidth(1f);
            paint.setColor(colors.get(groups.get(groupPosition).get(childPosition).id - 1));
            canvas.drawRect(box, paint);
            ImageView imageView = convertView.findViewById(R.id.indicator);
            imageView.setImageBitmap(bitmap);

            return convertView;
        }

        @Override
        public boolean isChildSelectable(int groupPosition, int childPosition) {
            return true;
        }
        public void initstats()
        {
            amountgroup[0] = 0;
            amountgroup [1] = 0;
            reclistpos.clear();
            Cursor cursor = db.query("categories", new String[] {"id", "name"},
                    "posneg = ?", new String[]{"0"},null,
                    null, "id ASC");
            if (cursor!=null) {
                while (cursor.moveToNext()){
                    Rec rec = new Rec();
                    rec.name = cursor.getString(cursor.getColumnIndex("name"));
                    rec.id = cursor.getInt(cursor.getColumnIndex("id"));
                    reclistpos.add(rec);
                }
                cursor.close();
            }
            reclistneg.clear();
            Cursor curs = db.query("categories", new String[] {"id", "name"},
                    "posneg = ?", new String[]{"1"},null,
                    null, "id ASC");
            if (curs!=null) {
                while (curs.moveToNext()){
                    Rec rec = new Rec();
                    rec.name = curs.getString(curs.getColumnIndex("name"));
                    rec.id = curs.getInt(curs.getColumnIndex("id"));
                    rec.amount = 0;
                    reclistneg.add(rec);
                }
                curs.close();
            }
            for (Rec rec:reclistpos
            ) {
                Cursor cursor2 = db.query("money", new String[]{"amount"},
                        "date >= ? and date <= ? and categoryid = ?",
                        new String[]{Integer.toString(date1), Integer.toString(date2),
                                Integer.toString(rec.id)}, null, null, null);
                if (cursor2!=null) {
                    while (cursor2.moveToNext()){
                        rec.amount+=cursor2.getDouble(cursor2.getColumnIndex("amount"));
                    }
                    cursor2.close();
                    amountgroup[0]+=rec.amount;
                }
            }
            for (Rec rec:reclistneg
            ) {
                Cursor cursor2 = db.query("money", new String[]{"amount"},
                        "date >= ? and date <= ? and categoryid = ?",
                        new String[]{Integer.toString(date1), Integer.toString(date2),
                                Integer.toString(rec.id)}, null, null, null);
                if (cursor2!=null) {
                    while (cursor2.moveToNext()){
                        rec.amount+=cursor2.getDouble(cursor2.getColumnIndex("amount"));
                    }
                    cursor2.close();
                    amountgroup[1]+=rec.amount;
                }
            }
            for (int i = reclistneg.size()-1; i>0-1; i--) {
                if (reclistneg.get(i).amount == 0){
                    reclistneg.remove(i);
                }
            }
            for (int i = reclistpos.size()-1; i>0-1; i--) {
                if (reclistpos.get(i).amount == 0){
                    reclistpos.remove(i);
                }
            }
            groups.clear();
            groups.add(reclistpos);
            groups.add(reclistneg);
            adapter.notifyDataSetChanged();
            concat.clear();
            for (Rec rec:reclistpos
                 ) {
                concat.add(rec);
            }
            for (Rec rec:reclistneg
            ) {
                concat.add(rec);
            }
            int maxid = -1;
            for (Rec rec: concat
                 ) {
                if (rec.id>maxid) maxid = rec.id;
            }
            while (maxid>colors.size()) {
                colors.add(Color.argb(255, (int)(Math.random()*255), (int)(Math.random()*255), (int)(Math.random()*255)));
            }
            Bitmap bitmap = Bitmap.createBitmap(Resources.getSystem().getDisplayMetrics().widthPixels * 2/3,
                    Resources.getSystem().getDisplayMetrics().widthPixels * 2/3,
                    Bitmap.Config.ARGB_8888);
            drawPieChart(bitmap, colors, concat);
            ivmain = findViewById(R.id.diagram);
            ivmain.setImageBitmap(bitmap);
            TextView timedelta = findViewById(R.id.timedelta);
            Cursor cursor228 = db.query("money", new String[] {"amount", "categoryid"}, null, null, null, null, null);
            Cursor cursor69 = db.query("categories", new String[] {"posneg"}, null, null, null, null, "id ASC");
            double g = 0;
            ArrayList <Integer> posneg = new ArrayList<Integer>();
            while (cursor69.moveToNext()){
                posneg.add(cursor69.getInt(cursor69.getColumnIndex("posneg")));
            }
            while (cursor228.moveToNext()){
                g+=cursor228.getLong(cursor228.getColumnIndex("amount"))*Math.pow(-1, posneg.get(cursor228.getInt(cursor228.getColumnIndex("categoryid"))-1));
            }
            cursor69.close();
            cursor228.close();
            String big = resourcestrings[0]+": ";
            if (g%1 == 0){ big = big.concat(Integer.toString((int)g));}
            else {big = big.concat(Double.toString(g));}
            SpannableString ss = new SpannableString(big);
            if (g > 0) {
                ss.setSpan(new ForegroundColorSpan(Color.GREEN), resourcestrings[0].length()+2, big.length(), Spanned.SPAN_EXCLUSIVE_INCLUSIVE);
            }
            if (g < 0) {
                ss.setSpan(new ForegroundColorSpan(Color.RED), resourcestrings[0].length()+2, big.length(), Spanned.SPAN_EXCLUSIVE_INCLUSIVE);
            }
            timedelta.setText(ss);
        }
    }
    public class Rec {
        String name;
        int id;
        double amount;
    }
}