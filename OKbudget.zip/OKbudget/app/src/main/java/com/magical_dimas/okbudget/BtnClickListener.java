package com.magical_dimas.okbudget;

import android.view.View;

public interface BtnClickListener {
 //   public abstract void onBtnClick(View v, int position, String edcom, String edam);
 public abstract void onBtnClick(View v, int position, Item it);
}
