package com.magical_dimas.okbudget;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.Switch;

import androidx.annotation.Nullable;

import java.util.Locale;

import static com.magical_dimas.okbudget.MainActivity.LOG_TAG;

public class DBhelper extends SQLiteOpenHelper {
    public DBhelper(@Nullable Context context) {
        super(context, "basic", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        Log.i(LOG_TAG, "onCreate database");
        db.execSQL("create table money ("
                + "id integer primary key autoincrement,"
                + "date integer,"
                + "categoryid integer,"
                + "comment text,"
                + "amount real"
                + ");");
        db.execSQL("create table categories ("
                + "id integer primary key autoincrement,"
                + "name text,"
                + "posneg int"
                + ");");
        db.execSQL("create table settings("
        +"language integer" // 0 - английский, 1 - русский
        +");");
        ContentValues weeewee = new ContentValues();
        weeewee.put("language", 0);
        weeewee.put("theme", 0);
        db.insert("settings", null , weeewee);
        Locale.getDefault().getDisplayLanguage();
        for (int i = 0; i < 6; i++) {
            ContentValues cv = new ContentValues();
            switch (i){
                case 0:
                    cv.put("name", "Еда");
                    cv.put("posneg", 1);
                    break;
                case 1:
                    cv.put("name", "Ресторан");
                    cv.put("posneg", 1);
                    break;
                case 2:
                    cv.put("name", "Зарплата");
                    cv.put("posneg", 0);
                    break;
                case 3:
                    cv.put("name", "Дом");
                    cv.put("posneg", 1);
                    break;
                case 4:
                    cv.put("name", "Техника");
                    cv.put("posneg", 1);
                    break;
                case 5:
                    cv.put("name", "Машина");
                    cv.put("posneg", 1);
                    break;
            }
            db.insert("categories", null, cv);
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }
}
