package com.magical_dimas.okbudget;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.format.DateUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.ViewFlipper;

import androidx.annotation.NonNull;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import static com.magical_dimas.okbudget.Categories.groupAdapter;
import static com.magical_dimas.okbudget.Days.dayAdapter;
import static com.magical_dimas.okbudget.MainActivity.LOG_TAG;
import static com.magical_dimas.okbudget.MainActivity.dbhelper;
import static com.magical_dimas.okbudget.MainActivity.ischanged;
import static com.magical_dimas.okbudget.MainActivity.resourcestrings;
import static com.magical_dimas.okbudget.Statistics.adapter;

public class Editing extends Activity {

    Button date;
    Calendar calendar = Calendar.getInstance();
    Integer dateint;
    static CustomAdapter customAdapter;
    ListView listView;
    TextView datetext;
    EditText catname;
    Spinner nowediting, positiveornot;
    static ArrayAdapter arrayAdapterposneg, arrayAdaptercateg;
    private List<Item> rlist = new ArrayList<Item>();
    public static List<String> categ = new ArrayList<String>();
    private List <Integer> catposneg = new ArrayList<Integer>();
    String [] vars = new String[] {"Доход", "Расход"};
    static ViewFlipper viewFlipper1;
    static int savedi;


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_MASK_ADJUST);
        setContentView(R.layout.editing1);
        viewFlipper1 = (ViewFlipper) findViewById(R.id.viewflipper1);
        initcategedit();
        initelemedit();
    }

    private void initList() {

        rlist.clear();
        Cursor cursor = db.query("money",
                new String[]{"amount", "comment", "id", "categoryid"},
                "date = ?",
                new String[]{Integer.toString(dateint)},
                null,
                null,
                "id ASC"
        );
        int count = 0;
        if (cursor != null) {
            Log.i(LOG_TAG, "Showing values from money:");
            while (cursor.moveToNext()){
                count++;
                Item rec = new Item();
                rec.edit1 = cursor.getString(cursor.getColumnIndex("comment"));
                double g = cursor.getDouble(cursor.getColumnIndex("amount"));
                if (g%1 == 0) {
                    rec.edit2 = Integer.toString((int) g);
                }
                else {
                    rec.edit2 = Double.toString(g);
                }
                if (g == 0){
                    rec.edit2 = "";
                }
                rec.id = cursor.getInt(cursor.getColumnIndex("id"));
                rec.chosencategory = cursor.getInt(cursor.getColumnIndex("categoryid"));
                Log.i(LOG_TAG, (count) + ". amount = " + rec.edit2 + ", comment = " + rec.edit1+", id = "+rec.id);

                rlist.add(rec);
            }
        }
        cursor.close();
        if (rlist.size()==0){
            Item it = new Item();
            it.id = -1;
            rlist.add(it) ;
        }
        customAdapter.notifyDataSetChanged();
    }




    SQLiteDatabase db = dbhelper.getWritableDatabase();


    public void onclkcall(View v) {


        switch (v.getId()) {

            case R.id.datebt:
                new DatePickerDialog(Editing.this, d,
                        calendar.get(Calendar.YEAR),
                        calendar.get(Calendar.MONTH),
                        calendar.get(Calendar.DAY_OF_MONTH))
                        .show();
                break;
            case R.id.newitembt:
                ContentValues cv = new ContentValues();
                cv.put("comment", "");
                cv.put("amount", "");
                cv.put("date", dateint);
                cv.put("categoryid", 1);
                Log.i(LOG_TAG, "Insert in money:");
                long rowID = db.insert("money", null, cv);
                Log.i(LOG_TAG, "empty row inserted in money, ID = " + rowID);
                initList();
                break;
            case R.id.gotocated:
                viewFlipper1.showNext();
                break;
            case R.id.gotoeled:
                viewFlipper1.showPrevious();
                break;
            case R.id.newcat:
                ContentValues cvcat = new ContentValues();
                cvcat.put("name", "Empty");
                cvcat.put("posneg", 1); // 1 - расход   0 - доход
                Log.i(LOG_TAG, "Insert in categories:");
                long catrowid = db.insert("categories", null, cvcat);
                Log.i(LOG_TAG, "empty row inserted in categories, ID = " + catrowid);
                initcat();
                if (arrayAdaptercateg!=null)
                arrayAdaptercateg.notifyDataSetChanged();
                if (customAdapter!=null)
                    customAdapter.notifyDataSetChanged();
                break;
            case R.id.catupdatevalue:
                Log.i(LOG_TAG, "Updating values in categories");
                ContentValues cvcatupd = new ContentValues();
                cvcatupd.put("name", catname.getText().toString());
                cvcatupd.put("posneg", positiveornot.getSelectedItemPosition());
                db.update("categories", cvcatupd, "id = ?", new String[] {Integer.toString
                        (nowediting.getSelectedItemPosition()+1)});
                Log.i(LOG_TAG, "Values updated, id = "+(nowediting.getSelectedItemPosition()+1)+"," +
                        " " +
                        "name = "+catname.getText().toString()+", posneg = "+positiveornot.getSelectedItemPosition());
                initcat();
                if (arrayAdaptercateg!=null)
                arrayAdaptercateg.notifyDataSetChanged();
                if (adapter!=null)
                    adapter.initstats();
                if (groupAdapter!=null)
                    groupAdapter.initthis();
                if (dayAdapter!=null)
                    dayAdapter.init();
                break;
        }

    }

    private void setInitialDateTime() {

        datetext.setText(DateUtils.formatDateTime(this,
                calendar.getTimeInMillis(),
                DateUtils.FORMAT_SHOW_DATE | DateUtils.FORMAT_SHOW_YEAR));
        dateint = calendar.get(Calendar.DAY_OF_MONTH) + (calendar.get(Calendar.MONTH) + 1) * 100 +
                calendar.get(Calendar.YEAR) * 10000;
        initList();
    }

    DatePickerDialog.OnDateSetListener d = new DatePickerDialog.OnDateSetListener() {
        public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
            calendar.set(Calendar.YEAR, year);
            calendar.set(Calendar.MONTH, monthOfYear);
            calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
            setInitialDateTime();
        }
    };

    AdapterView.OnItemClickListener onItemClickListener = new AdapterView.OnItemClickListener() {

        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {}};

    protected void initelemedit (){
        date = (Button) findViewById(R.id.datebt);
        listView = (ListView) findViewById(R.id.listView);
        listView.setItemsCanFocus(true);
        datetext = (TextView) findViewById(R.id.datetext);
            customAdapter = new CustomAdapter(this, rlist, new BtnClickListener() {

                @Override
                public void onBtnClick(View v, int position, Item rec) {
                    switch (v.getId()) {
                        //на обновление
                        case R.id.bt1:
                            Log.i(LOG_TAG, "Updating values in money");
                            ContentValues cv = new ContentValues();
                            cv.put("comment", rec.edit1);
                            cv.put("amount", rec.edit2);
                            cv.put("date", dateint);
                            cv.put("categoryid", rec.chosencategory);
                            db.update("money", cv, "id = ?",
                                    new String[]{Integer.toString(rec.id)});
                            Log.i(LOG_TAG, "Values updated, id = " + rec.id + ", " +
                                    "" +
                                    "comment = " + rec.edit1 + ", amount = " + rec.edit2 + ", " +
                                    "categoryid = " + rec.chosencategory);
                            if (adapter!=null)
                                adapter.initstats();
                            if (groupAdapter!=null)
                                groupAdapter.initthis();
                            if (dayAdapter!=null)
                                dayAdapter.init();
                            break;
                        //на удаление
                        case R.id.bt2:
                            Log.i(LOG_TAG, "Deleting values from money");
                            db.delete("money", "id = ?", new String[]{Integer.toString(rec.id)});
                            Log.i(LOG_TAG, "Values deleted, id = " + rec.id);
                            initList();
                            if (adapter!=null)
                                adapter.initstats();
                            if (groupAdapter!=null)
                                groupAdapter.initthis();
                            if (dayAdapter!=null)
                                dayAdapter.init();
                            break;
                    }

                }

            });
        listView.setAdapter(customAdapter);
        listView.setOnItemClickListener(onItemClickListener);
        setInitialDateTime();
    }
    protected void initcategedit () {
        catname = (EditText) findViewById(R.id.categoryname);
        initcat();
        if (arrayAdapterposneg == null) {
            arrayAdapterposneg = new ArrayAdapter<String>(this,
                    R.layout.support_simple_spinner_dropdown_item, vars);
        }
        if (arrayAdaptercateg == null) {
            arrayAdaptercateg = new ArrayAdapter<String>(this,
                    R.layout.support_simple_spinner_dropdown_item, categ);
        }
            catname = (EditText) findViewById(R.id.categoryname);
            nowediting = (Spinner) findViewById(R.id.noweditingspin);
            positiveornot = (Spinner) findViewById(R.id.expenseincomespin);
        nowediting.setAdapter(arrayAdaptercateg);
        positiveornot.setAdapter(arrayAdapterposneg);
        nowediting.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                catname.setText(categ.get(i));
                positiveornot.setSelection(catposneg.get(i));
                savedi = i;
            }
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
            }
        });

    }
    private void initcat (){

        categ.clear();
        catposneg.clear();
        Cursor cursor = db.query("categories",
                new String[]{"name", "posneg"},
                null,
                null,
                null,
                null,
                "id ASC"
        );
            if (cursor != null) {
                while (cursor.moveToNext()) {
                    String str = cursor.getString(cursor.getColumnIndex("name"));
                    int temp = cursor.getInt(cursor.getColumnIndex("posneg"));
                    categ.add(str);
                    catposneg.add(temp);

            }
        }
        cursor.close();
    }
    public class CustomAdapter extends BaseAdapter {

        private int resource;
        private LayoutInflater inflater;

        Context context;
        private BtnClickListener mClickListener = null;
        private List<Item> list=null;

        SQLiteDatabase db = dbhelper.getWritableDatabase();
        ArrayList <String> catnames = new ArrayList<>();

        public CustomAdapter(Context context,  List<Item> list, BtnClickListener listener) {

            super();
            this.context = context;
            this.resource = R.layout.listitem;
            this.inflater = LayoutInflater.from(context);

            this.context = context;
            this.list=list;
            mClickListener = listener;
        }

        public View getView(int position, View convertView, ViewGroup parent) {

            View v = convertView;

            if (v == null) {
                LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                v = inflater.inflate(R.layout.listitem, null);
            }


            final Item rec = (Item) getItem(position);

            updatetextsed();

            TextView nmb = (TextView) v.findViewById(R.id.number);
            TextView tv1 = (TextView) v.findViewById(R.id.commentet);
            TextView tv2 = (TextView) v.findViewById(R.id.amountet);
            TextView date = (TextView) findViewById(R.id.datetext);
            date.setText(DateUtils.formatDateTime(context,
                    calendar.getTimeInMillis(),
                    DateUtils.FORMAT_SHOW_DATE | DateUtils.FORMAT_SHOW_YEAR));
            final EditText et1 = (EditText) v.findViewById(R.id.commentet);
            final EditText et2 = (EditText) v.findViewById(R.id.amountet);
            final Spinner spinner = (Spinner) v.findViewById(R.id.spinner2);
            initnames();
            ArrayAdapter adapter = new ArrayAdapter <String> (context,
                    R.layout.support_simple_spinner_dropdown_item, catnames);
            spinner.setAdapter(adapter);

                tv1.setText(rec.edit1);
                tv2.setText(rec.edit2);
            tv1.setHint(resourcestrings[12]);
            tv2.setHint(resourcestrings[11]);
            nmb.setText(String.valueOf(position+1));
            spinner.setSelection(rec.chosencategory-1);

            ImageButton bt1 = (ImageButton) v.findViewById(R.id.bt1);
            bt1.setTag(position);
            bt1.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View v) {
                    if(mClickListener != null) {
                        rec.edit1 = et1.getText().toString();
                        rec.edit2 = et2.getText().toString();
                        rec.chosencategory = spinner.getSelectedItemPosition()+1;
                        mClickListener.onBtnClick(v, (Integer) v.getTag(), rec);
                    }
                }
            });

            ImageButton bt2 = (ImageButton) v.findViewById(R.id.bt2);
            bt2.setTag(position);
            bt2.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View v) {
                    if(mClickListener != null) {
                        rec.edit1 = et1.getText().toString();
                        rec.edit2 = et2.getText().toString();
                        rec.chosencategory = spinner.getSelectedItemPosition()+1;
                        mClickListener.onBtnClick(v, (Integer) v.getTag(), rec);
                    }
                }
            });

            if (rlist.get(0).id == -1){
                tv1.setVisibility(View.INVISIBLE);
                tv1.setEnabled(false);
                tv2.setEnabled(false);
                nmb.setVisibility(View.INVISIBLE);
                bt1.setClickable(false);
                bt2.setClickable(false);
                bt1.setVisibility(View.INVISIBLE);
                bt2.setVisibility(View.INVISIBLE);
                tv2.setVisibility(View.INVISIBLE);
                spinner.setEnabled(false);
                spinner.setVisibility(View.INVISIBLE);
            }
            else {
                tv1.setEnabled(true);
                tv2.setEnabled(true);
                bt1.setClickable(true);
                bt2.setClickable(true);
                nmb.setVisibility(View.VISIBLE);
                tv1.setVisibility(View.VISIBLE);
                tv2.setVisibility(View.VISIBLE);
                bt1.setVisibility(View.VISIBLE);
                bt2.setVisibility(View.VISIBLE);
                spinner.setVisibility(View.VISIBLE);
                spinner.setEnabled(true);
            }
            if (ischanged) {
                catname.setText(categ.get(savedi));
                positiveornot.setSelection(catposneg.get(savedi));
                ischanged = false;
                initcategedit();
            }

            return v;

        }

        private void initnames (){

            catnames.clear();
            Cursor cursor = db.query("categories", new String[] {"name"}, null,
                    null, null, null, "id ASC");
            cursor.moveToLast();
            int count = cursor.getPosition();
            for (int i = 0; i < count+1; i++) {
                if (cursor != null) {
                    cursor.moveToPosition(i);
                    catnames.add(cursor.getString(cursor.getColumnIndex("name")));
                }
            }
            cursor.close();

        }

        @Override
        public int getCount() {
            if(list==null) return 0;
            return list.size();
        }

        @Override
        public Object getItem(int position) {
            return list.get(position);
        }

        @Override
        public long getItemId(int position) {

            return position;
        }
    }
    public void updatetextsed (){
        Button bt = findViewById(R.id.datebt);
        bt.setText(resourcestrings[10]);
        Button but = findViewById(R.id.gotocated);
        but.setText(resourcestrings[9]);
        Button but1 = findViewById(R.id.gotoeled);
        but1.setText(resourcestrings[13]);
        TextView nowedit = (TextView) findViewById(R.id.textedcat);
        nowedit.setText(resourcestrings[14]);
        TextView tttt = (TextView) findViewById(R.id.categoryname);
        tttt.setHint(resourcestrings[22]);
        Button but228 = (Button) findViewById(R.id.newcat);
        but228.setText(resourcestrings[15]);
        vars[0]=resourcestrings[23];
        vars[1]=resourcestrings[24];
    }

}